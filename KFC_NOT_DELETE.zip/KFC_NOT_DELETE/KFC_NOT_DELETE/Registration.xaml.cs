﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFC_NOT_DELETE
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        public DB.G03Entities2 connection = new DB.G03Entities2();
        public Registration()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string rolename = NameT.Text;
            string rolepassword = PasswordT.Text;
            string phone = PhoneT.Text;
            string rolepatro = PatronymicT.Text;
            string sname = SNameT.Text;
            string adress = AddressT.Text;
            if (rolename.Length != 0)
            {
                if (rolepassword.Length != 0)
                {
                    if (phone.Length != 0)
                    {
                        if (rolepatro.Length != 0)
                        {
                            if (sname.Length != 0)
                            {
                                DB.Employee client = new DB.Employee(); 
                                client.Phone = phone;   
                                client.Password = rolepassword; 
                                client.Name = rolename; 
                                client.Surename = sname;    
                                client.Patronymic = rolepatro;
                                client.Position = "Клиент";
                                connection.Employee.Add(client);
                               

                                DB.Client client1 = new DB.Client();    
                                client1.Phone = phone;
                                client1.FullName = rolename;
                                client1.Address = adress;
                                client1.PasswordClient = rolepassword;
                                connection.Client.Add(client1);
                                connection.SaveChanges();
                                RegFrame.Navigate(new MainWindow());
                            }
                            else
                            {
                                MessageBox.Show("Введите отчество.");
                                return;
                            }
                                
                        }
                        else
                        {
                            MessageBox.Show("Введите фамилию.");
                            return;
                        } 

                    } else
                    {
                        MessageBox.Show("Введите телефон.");
                        return;
                    }

                }
                else
                {
                    MessageBox.Show("Введите пароль.");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Введите имя.");
                return;
            }
        }
    }
}
