﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFC_NOT_DELETE
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public DB.G03Entities2 connection = new DB.G03Entities2();
        public MainWindow()
        {
            InitializeComponent();
            UpdateBox();
        }

        
        
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Reg.Visibility = Visibility.Hidden;
            string rolename = BoxWork.Text;
            string rolepassword = PasswordText.Text;
            if (BoxWork.SelectedIndex != -1)
            {
                if (rolepassword.Length != 0)
                {
                    DB.Employee basa = (DB.Employee)connection.Employee.Where(a => a.Position == rolename && a.Password == rolepassword).FirstOrDefault();
                    if (basa == null)
                    {
                        MessageBox.Show("Неверные данные.");
                        return;
                    }
                    else
                    {
                        if (rolename == "Официант" || rolename == "Кассир")
                            NavFreme.Navigate(new Ofic());
                        if (rolename == "Повар")
                            NavFreme.Navigate(new Povar());
                        if (rolename == "Клиент")
                            NavFreme.Navigate(new Client());
                    }
                }
                else
                {
                    MessageBox.Show("Введите пароль для запуска нужного приложения.");
                    return;
                }
            } else
            {
                MessageBox.Show("Выберите роль для запуска нужного приложения.");
                return;
            }
        }

        private void UpdateBox()
        {
            foreach (DB.Role r in connection.Role.ToList())
            {
                BoxWork.Items.Add(r.NameRole);
            }
        }

        private void NavFreme_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void ShowReg(object sender, SelectionChangedEventArgs e)
        {
            if (BoxWork.SelectedIndex == 1)
            {
                Reg.Visibility = Visibility.Visible;
            } else
            {
                Reg.Visibility = Visibility.Hidden;
            }
        }

        private void Registr_Click(object sender, RoutedEventArgs e)
        {
            Reg.Visibility = Visibility.Hidden;
            NavFreme.Navigate(new Registration());
            
        }
    }
}
