﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFC_NOT_DELETE
{
    /// <summary>
    /// Логика взаимодействия для Povar.xaml
    /// </summary>
    public partial class Povar : Page
    {
        public DB.G03Entities2 connection = new DB.G03Entities2();
        private DB.OrderCompound selectedCompound = null;
        public Povar()
        {
            InitializeComponent();
            BuildDish();
        }

        void BuildDish()
        {
            DishStack.Children.Clear();
            var orders = connection.Order.Where(o => o.Status != "Готов").ToList();
            foreach (var order in orders)
            {
                var compounds = order.OrderCompound.ToList();

                foreach (var compound in compounds)
                {
                    var dish = compound.Dish1;

                    Border border1 = new Border();
                    StackPanel stack1 = new StackPanel();
                    Button button = new Button();
                    button.DataContext = compound;
                    button.Content = dish.Name + " " + compound.Count + " " + compound.Status;
                    button.Click += ButtonIngredient;
                    border1.Child = stack1;
                    stack1.Children.Add(button);

                    DishStack.Children.Add(border1);
                }
            }
        }

        private void ButtonIngredient(object sender, RoutedEventArgs e)
        {
            IngridientStack.Children.Clear();
            var button = sender as Button;
            if (button != null)
            {
                selectedCompound = button.DataContext as DB.OrderCompound;
                if (selectedCompound != null)
                {
                    var ingredients = selectedCompound.Dish1.DishCompound.ToList();
                    foreach (var d in ingredients)
                    {
                        Border border2 = new Border();

                        StackPanel stack2 = new StackPanel();

                        TextBlock textBlock = new TextBlock();

                        textBlock.Text = d.Ingredient1.Name;

                        border2.Child = stack2;
                        stack2.Children.Add(textBlock);
                        IngridientStack.Children.Add(border2);
                    }
                }
            }
        }

        private void Good_Click(object sender, RoutedEventArgs e)
        {
            if (selectedCompound == null) { return; }

            var currentCompound = connection.OrderCompound.Where(c => c.Order == selectedCompound.Order && c.Dish == selectedCompound.Dish).FirstOrDefault();
            if (currentCompound != null)
            {
                if (currentCompound.Status == "Готов") return;

                currentCompound.Status = "Готов";
                int r = connection.SaveChanges();
                if (r > 0)
                {
                    MessageBox.Show("Статус " + r + " блюд обновлен");

                    CheckOrder(selectedCompound.Order);
                }
            }
        }

        private void CheckOrder(long order) 
        {
            var list = connection.OrderCompound.Where(o => o.Order == order).ToList();
            if (list.Count > 0)
            {
                bool complete = true;
                foreach (var item in list)
                {
                    complete &= item.Status == "Готов";                    
                }
                if (complete == true)
                {
                    var orderToUpdate = connection.Order.Where(o => o.ID == order).FirstOrDefault();
                    orderToUpdate.Status = "Готов";
                    int r = connection.SaveChanges();
                    if (r > 0)
                    {
                        MessageBox.Show("Статус " + r + " заказа(-ов) обновлен");
                    }
                    
                }
            }
            BuildDish();
        }
    }
}
