﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFC_NOT_DELETE
{
    public partial class Ofic : Page 
    {
        public DB.G03Entities2 connection = new DB.G03Entities2();
        public Dictionary<DB.Dish, int> DishOrderList = new Dictionary<DB.Dish, int>();    
        public Ofic()
        {
            InitializeComponent();
            BuildCategori();
        }

        void BuildCategori()
        {
            foreach (DB.Category cat in connection.Category.ToList())
            {
                Border border1 = new Border();

                StackPanel stack1 = new StackPanel();

                Button button = new Button();
                button.DataContext = cat;
                button.Content = cat.NameCategory.ToString();
                button.Click += CategoriOpen;

                border1.Child = stack1;
                stack1.Children.Add(button);

                CategoriPanel.Children.Add(border1);

            }
        }
        private void CategoriOpen(object sender, RoutedEventArgs e)
        {
            DishPanel.Children.Clear();
            var button = sender as Button;
            if (button != null)
            {
                var cat = button.DataContext as DB.Category;
                if (cat != null)
                {
                    var dishes = connection.Dish.Where(d => d.CategoryDish == cat.NameCategory).ToList();
                    foreach (var dish in dishes)
                    {                    
                        Border border2 = new Border();
                        
                        StackPanel stack2 = new StackPanel();
                        stack2.Orientation = Orientation.Horizontal;

                        Button button2 = new Button();
                        button2.Width = 120;
                        button2.Height = 25;
                        button2.HorizontalAlignment = HorizontalAlignment.Left;
                        button2.Content = dish.Name.ToString();
                        button2.Click += Button2_Click;
                        button2.DataContext = dish;
                        

                        foreach (var imagdish in dish.Image)
                        {
                            Image image = new Image();
                            image.Width = 100;
                            image.Height = 100;
                            image.HorizontalAlignment = HorizontalAlignment.Left;
                            image.Margin = new Thickness(10, -40, -110, 80);
                            BitmapImage bitmap = new BitmapImage();
                            bitmap.BeginInit();
                            if (imagdish.URl != null)
                            {
                                bitmap.UriSource = new Uri(imagdish.URl, UriKind.RelativeOrAbsolute);
                            }
                            bitmap.EndInit();
                            image.Stretch = Stretch.UniformToFill;
                            image.Source = bitmap;
                            stack2.Children.Add(image);
                        }
                        border2.Child = stack2;
                        stack2.Children.Add(button2);
                        DishPanel.Children.Add(border2);
                    }
                }
            }
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {           
            Button button = sender as Button;
            if (button == null) { return; }
            
            var dish = button.DataContext as DB.Dish;
       
            if (dish != null)
            {
                if (DishOrderList.ContainsKey(dish) == true)
                {
                    DishOrderList[dish]++;
                } else
                {
                    DishOrderList.Add(dish, 1);
                }               
            }
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (DishOrderList.Count != 0)
            {
                DB.Order order = new DB.Order();
                order.Client = "84567841232";
                order.Employee = "86734523412";
                order.Date = DateTime.Now;
                order.Status = "В ожиданий";
                connection.Order.Add(order);
                connection.SaveChanges();

                foreach (var ordercom in DishOrderList)
                {
                    int st = (int)(ordercom.Value * ordercom.Key.Price);
                    DB.OrderCompound ordercompound = new DB.OrderCompound();
                    ordercompound.Order = order.ID;
                    ordercompound.Dish = ordercom.Key.ID;
                    ordercompound.Price = st;
                    ordercompound.Count = ordercom.Value;
                    ordercompound.Status = "В ожиданий";
                    connection.OrderCompound.Add(ordercompound);
                    connection.SaveChanges();
                }
                OficFrame.Navigate(new OrderStatusPage());
            } else
            {
                MessageBox.Show("Сначала выберите товар.");
                return;
            }
            
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Clear.Visibility = Visibility.Visible;
            DishPanel.Children.Clear();
            foreach (var v in DishOrderList)
            {
                Border border = new Border();
                StackPanel stack3 = new StackPanel();                      
                TextBlock textBlock = new TextBlock();
                textBlock.Text = v.Key.Name + " " + v.Value + "шт" + " " + v.Key.Price * v.Value;
                border.Child = stack3;
                stack3.Children.Add(textBlock);
                DishPanel.Children.Add(border);
            }
        }

        private void Button_min_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button == null) { return; }
            var min = button.DataContext as DB.Dish;
            if (min != null)
            {
                
                MessageBox.Show("Ok");                            
            }
            else
            {
                MessageBox.Show("No Ok");
            }

        }

        private void Button_plus_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            OficFrame.Navigate(new OrderStatusPage());
        }

        private void ButtonClear(object sender, RoutedEventArgs e)
        {
            DishPanel.Children.Clear();
            DishOrderList.Clear();
        }
    }
}
