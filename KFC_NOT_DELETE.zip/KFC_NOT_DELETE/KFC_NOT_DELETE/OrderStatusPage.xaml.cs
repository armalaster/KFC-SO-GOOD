﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace KFC_NOT_DELETE
{
    /// <summary>
    /// Логика взаимодействия для OrderStatusPage.xaml
    /// </summary>
    public partial class OrderStatusPage : Page
    {
        public DB.G03Entities2 connection = new DB.G03Entities2();
        public OrderStatusPage()
        {
            InitializeComponent();
            BuildOrderStatus();
        }

        void BuildOrderStatus()
        {
            var orders = connection.Order.OrderByDescending(o => o.ID).Take(10).ToList();

            
            foreach (var or in orders)
            {                
                Border border = new Border();

                StackPanel stack = new StackPanel();

                Button button = new Button();
                button.Content = "Номер заказа: " + or.ID + " Статус заказа: " + or.Status; 
                button.DataContext = or;
                button.Click += Button_Click1;

                Image image = new Image();
                BitmapImage bitmap = new BitmapImage();
                image.Width = 25;
                image.Height = 25;
                image.HorizontalAlignment = HorizontalAlignment.Right;
                image.Margin = new Thickness(10, -22, -23, 0);
                bitmap.BeginInit();
                if (or.Status == "В ожиданий")
                {
                    bitmap.UriSource = new Uri("/Image/Ellow.png", UriKind.RelativeOrAbsolute);
                } else if (or.Status == "Готов")
                {
                    bitmap.UriSource = new Uri("/Image/Green.png", UriKind.RelativeOrAbsolute);
                }
                bitmap.EndInit();
                image.Stretch = Stretch.UniformToFill;
                image.Source = bitmap;
                border.Child = stack;
                stack.Children.Add(button);
                stack.Children.Add(image);
                OrderPanel.Children.Add(border);
            }
        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            OrderStack.Children.Clear();
            var button = sender as Button;
            if (button != null)
            {
                var showorder = button.DataContext as DB.Order;
                if (showorder != null)
                {
                    var order = connection.OrderCompound.Where(o => o.Order == showorder.ID).ToList();
                    foreach (var or in order)
                    {
                        Border border = new Border();

                        StackPanel stack = new StackPanel();
                        TextBlock text = new TextBlock();
                        text.Text = ("№" + or.Order + " Блюдо: " + or.Dish1.Name + " Цена: " + or.Price + " Количество: " + or.Count).ToString();
                        border.Child = stack;
                        stack.Children.Add(text);
                        OrderStack.Children.Add(border);
                    }
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            OrderStack.Children.Clear();
            OrderFrame.Navigate(new Ofic());
        }
    }
}
