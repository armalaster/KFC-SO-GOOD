﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace KFC_NOT_DELETE
{
    /// <summary>
    /// Логика взаимодействия для Client.xaml
    /// </summary>
    public partial class Client : Page
    {
        public DB.G03Entities2 connection = new DB.G03Entities2();
        public Dictionary<DB.Dish, int> DishOrderList = new Dictionary<DB.Dish, int>();
        public Client()
        {
            InitializeComponent();
            BuildDish();
        }

        void BuildDish()
        {
            foreach (DB.Category cat in connection.Category.ToList())
            {
                Border border1 = new Border();

                StackPanel stack1 = new StackPanel();

                Button button = new Button();
                button.DataContext = cat;
                button.Content = cat.NameCategory.ToString();
                button.Click += CategoriOpen;

                border1.Child = stack1;
                stack1.Children.Add(button);

                ClientMenuStack.Children.Add(border1);
            }
        }

        private void CategoriOpen(object sender, RoutedEventArgs e)
        {
            ClientDishStack.Children.Clear();
            var button = sender as Button;
            if (button != null)
            {
                var cat = button.DataContext as DB.Category;
                if (cat != null)
                {
                    var dishes = connection.Dish.Where(d => d.CategoryDish == cat.NameCategory).ToList();
                    foreach (var dish in dishes)
                    {
                        Border border2 = new Border();

                        StackPanel stack2 = new StackPanel();
                        stack2.Orientation = Orientation.Horizontal;
                        Button button2 = new Button();
                        button2.Width = 120;
                        button2.Height = 25;
                        button2.HorizontalAlignment = HorizontalAlignment.Left;
                        button2.Content = dish.Name.ToString();
                        button2.Click += Button2_Click;
                        button2.DataContext = dish;

                        foreach (var imagdish in dish.Image)
                        {
                            Image image = new Image();
                            image.Width = 100;
                            image.Height = 100;
                            image.HorizontalAlignment = HorizontalAlignment.Left;
                            image.Margin = new Thickness(10, -40, -110, 80);
                            BitmapImage bitmap = new BitmapImage();
                            bitmap.BeginInit();
                            if (imagdish.URl != null)
                            {
                                bitmap.UriSource = new Uri(imagdish.URl, UriKind.RelativeOrAbsolute);
                            }
                            bitmap.EndInit();
                            image.Stretch = Stretch.UniformToFill;
                            image.Source = bitmap;
                            stack2.Children.Add(image);
                        }

                        border2.Child = stack2;
                        stack2.Children.Add(button2);
                        ClientDishStack.Children.Add(border2);

                    }
                }
            }
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            if (button == null) { return; }

            var dish = button.DataContext as DB.Dish;
            if (dish != null)
            {
                if (DishOrderList.ContainsKey(dish) == true)
                {
                    DishOrderList[dish]++;
                }
                else
                {
                    DishOrderList.Add(dish, 1);
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (DishOrderList.Count != 0)
            {
                DB.Order order = new DB.Order();
                order.Client = "7834561268";
                order.Employee = null;
                order.Date = DateTime.Now;
                order.Status = "В ожиданий";
                connection.Order.Add(order);
                connection.SaveChanges();

                foreach (var ordercom in DishOrderList)
                {
                    int st = (int)(ordercom.Value * ordercom.Key.Price);
                    DB.OrderCompound ordercompound = new DB.OrderCompound();
                    ordercompound.Order = order.ID;
                    ordercompound.Dish = ordercom.Key.ID;
                    ordercompound.Price = st;
                    ordercompound.Count = ordercom.Value;
                    ordercompound.Status = "В ожиданий";
                    connection.OrderCompound.Add(ordercompound);
                    connection.SaveChanges();
                }

            }else
            {
                MessageBox.Show("Сначала выберите товар.");
                return;
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ClearClient.Visibility = Visibility.Visible;
            ClientDishStack.Children.Clear();
            foreach (var v in DishOrderList)
            {
                StackPanel stack3 = new StackPanel();
                TextBlock textBlock = new TextBlock();
                textBlock.Text = v.Key.Name + " " + v.Value + "шт" + " " + v.Key.Price * v.Value;
                stack3.Children.Add(textBlock);
                ClientDishStack.Children.Add(stack3);
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ClientDishStack.Children.Clear();
            DishOrderList.Clear();
        }
    }
}
